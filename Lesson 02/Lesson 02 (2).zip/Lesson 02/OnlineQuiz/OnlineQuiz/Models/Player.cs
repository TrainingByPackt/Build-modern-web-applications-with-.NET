﻿namespace OnlineQuiz.Models
{
    public class Player
    {
        public int Id { get; set; }
        public PlayerTypes PlayerTypes { get; set; }
        public string Name { get; set; }
    }
}