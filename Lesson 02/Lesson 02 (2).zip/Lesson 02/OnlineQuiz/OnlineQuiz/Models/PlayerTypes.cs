﻿namespace OnlineQuiz.Models
{
    public enum PlayerTypes
    {
        Human,
        AI
    }
}