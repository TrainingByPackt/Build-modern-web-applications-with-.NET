﻿namespace OnlineQuiz.Models
{
    public class QuestionCategory
    {
        public int Id { get; set; }
        public string Description { get; set; }
    }
}